package ConnectionDatabase;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCUtils {

    private static final String URL =
        "jdbc:sqlserver://localhost:1433;" +
        "databaseName=baodientu;" +
        "encrypt=false;" +              // rất quan trọng
        "trustServerCertificate=true";  // tránh SSL error

    private static final String USER = "sa";
    private static final String PASS = "123"; // sửa theo SQL của bạn

    public static Connection getConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(URL, USER, PASS);

            System.out.println(">>> Kết nối SQL thành công!");
            return conn;

        } catch (Exception e) {
            System.out.println(">>> Kết nối SQL THẤT BẠI!");
            e.printStackTrace();
            return null;
        }
    }
}
