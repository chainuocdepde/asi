package CONTROLLER;

import DAO.DangKyDAO;
import ENTITY.DangKyEntity;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/admin-nhanvien")
public class dangkycontroller extends HttpServlet {

    DangKyDAO dao = new DangKyDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        String id = req.getParameter("id");

        if ("delete".equals(action) && id != null) {
            dao.xoaTaiKhoan(id);
            resp.sendRedirect("admin-nhanvien");
            return;
        }

        // Load danh sách nhân viên
        List<DangKyEntity> list = dao.findAll();
        req.setAttribute("listNhanVien", list);
        req.getRequestDispatcher("Dangky.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String ma = req.getParameter("maNguoiDung");
        String hoTen = req.getParameter("hoTen");
        String email = req.getParameter("email");
        String dienThoai = req.getParameter("dienThoai");
        boolean gioiTinh = "1".equals(req.getParameter("gioiTinh"));
        boolean vaiTro = "1".equals(req.getParameter("vaiTro"));

        Date ngaySinh;
        try {
            ngaySinh = new SimpleDateFormat("yyyy-MM-dd").parse(req.getParameter("ngaySinh"));
        } catch (Exception e) {
            ngaySinh = new Date();
        }

        DangKyEntity nv = new DangKyEntity();
        nv.setMaNguoiDung(ma);
        nv.setHoTen(hoTen);
        nv.setEmail(email);
        nv.setDienThoai(dienThoai);
        nv.setGioiTinh(gioiTinh);
        nv.setNgaySinh(ngaySinh);
        nv.setVaiTro(vaiTro);

        if (req.getParameter("isEdit") != null && !req.getParameter("isEdit").isEmpty()) {
            dao.capNhatTaiKhoan(nv);
        } else {
            nv.setMatKhau("123456"); // mật khẩu mặc định
            dao.dangKyTaiKhoan(nv);
        }

        resp.sendRedirect("admin-nhanvien");
    }
}
