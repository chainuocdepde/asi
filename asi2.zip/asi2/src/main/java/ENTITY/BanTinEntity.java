package ENTITY;

import java.util.Date;

public class BanTinEntity {
    private String maBanTin;
    private String tieuDe;
    private String noiDung;
    private String hinhAnh;
    private Date ngayDang;
    private int luotXem;
    private String maLoai;
    private String maTacGia;

    // Getter & Setter
    public String getMaBanTin() { return maBanTin; }
    public void setMaBanTin(String maBanTin) { this.maBanTin = maBanTin; }

    public String getTieuDe() { return tieuDe; }
    public void setTieuDe(String tieuDe) { this.tieuDe = tieuDe; }

    public String getNoiDung() { return noiDung; }
    public void setNoiDung(String noiDung) { this.noiDung = noiDung; }

    public String getHinhAnh() { return hinhAnh; }
    public void setHinhAnh(String hinhAnh) { this.hinhAnh = hinhAnh; }

    public Date getNgayDang() { return ngayDang; }
    public void setNgayDang(Date ngayDang) { this.ngayDang = ngayDang; }

    public int getLuotXem() { return luotXem; }
    public void setLuotXem(int luotXem) { this.luotXem = luotXem; }

    public String getMaLoai() { return maLoai; }
    public void setMaLoai(String maLoai) { this.maLoai = maLoai; }

    public String getMaTacGia() { return maTacGia; }
    public void setMaTacGia(String maTacGia) { this.maTacGia = maTacGia; }
}
