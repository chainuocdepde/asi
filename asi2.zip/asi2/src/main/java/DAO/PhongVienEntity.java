package DAO;

public class PhongVienEntity {

    private int MaPhongVien;      // PK – tự tăng
    private String TenPhongVien;
    private String Email;
    private String Sdt;
    private String MatKhau;
    private String VaiTro;        // "Admin" | "PhongVien"

    public PhongVienEntity() {
    }

    public int getMaPhongVien() {
        return MaPhongVien;
    }

    public void setMaPhongVien(int maPhongVien) {
        MaPhongVien = maPhongVien;
    }

    public String getTenPhongVien() {
        return TenPhongVien;
    }

    public void setTenPhongVien(String tenPhongVien) {
        TenPhongVien = tenPhongVien;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getSdt() {
        return Sdt;
    }

    public void setSdt(String sdt) {
        Sdt = sdt;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String matKhau) {
        MatKhau = matKhau;
    }

    public String getVaiTro() {
        return VaiTro;
    }

    public void setVaiTro(String vaiTro) {
        VaiTro = vaiTro;
    }
}
