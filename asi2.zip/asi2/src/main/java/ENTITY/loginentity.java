package ENTITY;

public class loginentity {
    private String maNguoiDung;
    private String matKhau;

    public loginentity() {}

    public loginentity(String maNguoiDung, String matKhau) {
        this.maNguoiDung = maNguoiDung;
        this.matKhau = matKhau;
    }

    public String getMaNguoiDung() {
        return maNguoiDung;
    }

    public void setMaNguoiDung(String maNguoiDung) {
        this.maNguoiDung = maNguoiDung;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }
}
