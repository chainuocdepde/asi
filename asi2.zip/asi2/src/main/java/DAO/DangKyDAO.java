package DAO;

import ENTITY.DangKyEntity;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import ConnectionDatabase.JDBCUtils;

public class DangKyDAO {

    // Thêm nhân viên
    public boolean dangKyTaiKhoan(DangKyEntity nv) {
        String sql = "INSERT INTO NguoiDung "
                + "(MaNguoiDung, MatKhau, HoTen, NgaySinh, GioiTinh, DienThoai, Email, VaiTro) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nv.getMaNguoiDung());
            ps.setString(2, nv.getMatKhau());
            ps.setString(3, nv.getHoTen());
            ps.setDate(4, new Date(nv.getNgaySinh().getTime()));
            ps.setBoolean(5, nv.isGioiTinh());
            ps.setString(6, nv.getDienThoai());
            ps.setString(7, nv.getEmail());
            ps.setBoolean(8, nv.isVaiTro());
            return ps.executeUpdate() > 0;
        } catch(SQLException e) { e.printStackTrace(); }
        return false;
    }

    // Cập nhật nhân viên
    public boolean capNhatTaiKhoan(DangKyEntity nv) {
        String sql = "UPDATE NguoiDung SET "
                + "MatKhau=?, HoTen=?, NgaySinh=?, GioiTinh=?, DienThoai=?, Email=?, VaiTro=? "
                + "WHERE MaNguoiDung=?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nv.getMatKhau());
            ps.setString(2, nv.getHoTen());
            ps.setDate(3, new Date(nv.getNgaySinh().getTime()));
            ps.setBoolean(4, nv.isGioiTinh());
            ps.setString(5, nv.getDienThoai());
            ps.setString(6, nv.getEmail());
            ps.setBoolean(7, nv.isVaiTro());
            ps.setString(8, nv.getMaNguoiDung());
            return ps.executeUpdate() > 0;
        } catch(SQLException e) { e.printStackTrace(); }
        return false;
    }

    // Xóa nhân viên
    public boolean xoaTaiKhoan(String maNguoiDung) {
        String sql = "DELETE FROM NguoiDung WHERE MaNguoiDung=?";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maNguoiDung);
            return ps.executeUpdate() > 0;
        } catch(SQLException e) { e.printStackTrace(); }
        return false;
    }

    // Lấy tất cả nhân viên
    public List<DangKyEntity> findAll() {
        List<DangKyEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM NguoiDung";
        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()) {
                DangKyEntity nv = new DangKyEntity();
                nv.setMaNguoiDung(rs.getString("MaNguoiDung"));
                nv.setMatKhau(rs.getString("MatKhau"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setGioiTinh(rs.getBoolean("GioiTinh"));
                nv.setDienThoai(rs.getString("DienThoai"));
                nv.setEmail(rs.getString("Email"));
                nv.setVaiTro(rs.getBoolean("VaiTro"));
                list.add(nv);
            }
        } catch(SQLException e) { e.printStackTrace(); }
        return list;
    }
}
