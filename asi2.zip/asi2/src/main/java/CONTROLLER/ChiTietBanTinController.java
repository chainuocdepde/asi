package CONTROLLER;

import DAO.TrangChuDAO;
import ENTITY.BanTinEntity;
import ENTITY.LoaiTinEntity;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/chi-tiet")
public class ChiTietBanTinController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String maBanTin = request.getParameter("maBanTin");
            TrangChuDAO dao = new TrangChuDAO();

            // Load menu loại tin cho header
            List<LoaiTinEntity> menuLoaiTin = dao.getMenuLoaiTin();
            request.getSession().setAttribute("menuLoaiTin", menuLoaiTin);

            // Lấy chi tiết tin
            BanTinEntity tin = dao.getTinById(maBanTin);
            request.setAttribute("tin", tin);

            // Lấy thêm 5 bài khác
            List<BanTinEntity> listKhac = dao.getTinKhac(maBanTin);
            request.setAttribute("listKhac", listKhac);

            request.getRequestDispatcher("/ChiTietBanTin.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("❌ Lỗi ở Controller");
        }
    }
}


