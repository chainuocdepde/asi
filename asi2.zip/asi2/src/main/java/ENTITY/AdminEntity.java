package ENTITY;

import java.util.Date;

public class AdminEntity {

    private Integer maAdmin;
    private String hoTen;
    private String email;
    private String matKhau;
    private String vaiTro;    // SuperAdmin / Editor / Moderator
    private Boolean trangThai;
    private Date ngayTao;

    public AdminEntity() {
    }

    public Integer getMaAdmin() {
        return maAdmin;
    }

    public void setMaAdmin(Integer maAdmin) {
        this.maAdmin = maAdmin;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public String getVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(String vaiTro) {
        this.vaiTro = vaiTro;
    }

    public Boolean getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Boolean trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }
}
