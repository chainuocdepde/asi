package ENTITY;

import java.util.List;

public class TrangChuEntity {
    private List<LoaiTinEntity> menuLoaiTin;
    private List<BanTinEntity> tinTrangChu;
    private List<BanTinEntity> tinHot;
    private List<BanTinEntity> tinMoi;
    private List<BanTinEntity> tinDaXem;

    public List<LoaiTinEntity> getMenuLoaiTin() { return menuLoaiTin; }
    public void setMenuLoaiTin(List<LoaiTinEntity> menuLoaiTin) { this.menuLoaiTin = menuLoaiTin; }

    public List<BanTinEntity> getTinTrangChu() { return tinTrangChu; }
    public void setTinTrangChu(List<BanTinEntity> tinTrangChu) { this.tinTrangChu = tinTrangChu; }

    public List<BanTinEntity> getTinHot() { return tinHot; }
    public void setTinHot(List<BanTinEntity> tinHot) { this.tinHot = tinHot; }

    public List<BanTinEntity> getTinMoi() { return tinMoi; }
    public void setTinMoi(List<BanTinEntity> tinMoi) { this.tinMoi = tinMoi; }

    public List<BanTinEntity> getTinDaXem() { return tinDaXem; }
    public void setTinDaXem(List<BanTinEntity> tinDaXem) { this.tinDaXem = tinDaXem; }
}
