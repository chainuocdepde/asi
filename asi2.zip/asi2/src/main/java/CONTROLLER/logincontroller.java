package CONTROLLER;

import DAO.login;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginController")
public class logincontroller extends HttpServlet {

    private final login dao = new login();  // DÙNG DAO THẬT, KHÔNG GỌI CHÍNH MÌNH

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String user = request.getParameter("username");
        String pass = request.getParameter("password");

        System.out.println("Username nhận được từ JSP: " + user);
        System.out.println("Password nhận được từ JSP: " + pass);

        boolean kq = dao.checkLogin(user, pass);

        if (kq) {
            response.getWriter().write("OK");
        } else {
            response.getWriter().write("FAIL");
        }
    }
}
