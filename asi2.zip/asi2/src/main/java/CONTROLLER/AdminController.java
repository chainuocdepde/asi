package CONTROLLER;

import DAO.AdminDAO;
import DAO.BanTinDAO2;
import ENTITY.PhongVienEntity;
import ENTITY.BanTinEntity2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

@WebServlet("/admin")
public class AdminController extends HttpServlet {

    private AdminDAO adminDAO = new AdminDAO();
    private BanTinDAO2 banTinDAO = new BanTinDAO2();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "dashboard";

        try {
            switch (action) {

                case "listPV":
                    listPhongVien(req, resp);
                    break;

                case "deletePV":
                    deletePhongVien(req, resp);
                    break;

                case "listBV":
                    listBanTin(req, resp);
                    break;

                case "deleteBV":
                    deleteBanTin(req, resp);
                    break;

                default:
                    req.getRequestDispatcher("/admin/dashboard.jsp").forward(req, resp);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.getWriter().println("ERROR: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            switch (action) {

                case "addPV":
                    addPhongVien(req, resp);
                    break;

                case "updatePV":
                    updatePhongVien(req, resp);
                    break;

                case "addBV":
                    addBanTin(req, resp);
                    break;

                case "updateBV":
                    updateBanTin(req, resp);
                    break;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.getWriter().println("ERROR: " + e.getMessage());
        }
    }

    // =============================
    // 📌 PHÓNG VIÊN
    // =============================
    private void listPhongVien(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {

        List<PhongVienEntity> list = adminDAO.getAll();
        req.setAttribute("listPV", list);
        req.getRequestDispatcher("/admin/phongvien-list.jsp").forward(req, resp);
    }

    private void addPhongVien(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {

        PhongVienEntity pv = new PhongVienEntity();
        pv.setTenPhongVien(req.getParameter("ten"));
        pv.setEmail(req.getParameter("email"));
        pv.setSdt(req.getParameter("sdt"));
        pv.setMatKhau(req.getParameter("matkhau"));
        pv.setVaiTro(req.getParameter("vaitro"));

        adminDAO.dangKy(pv);

        resp.sendRedirect("admin?action=listPV");
    }

    private void updatePhongVien(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {

        PhongVienEntity pv = new PhongVienEntity();
        pv.setMaPhongVien(Integer.parseInt(req.getParameter("mapv")));
        pv.setTenPhongVien(req.getParameter("ten"));
        pv.setEmail(req.getParameter("email"));
        pv.setSdt(req.getParameter("sdt"));
        pv.setMatKhau(req.getParameter("matkhau"));
        pv.setVaiTro(req.getParameter("vaitro"));

        adminDAO.update(pv);

        resp.sendRedirect("admin?action=listPV");
    }

    private void deletePhongVien(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {

        int id = Integer.parseInt(req.getParameter("mapv"));
        adminDAO.delete(id);

        resp.sendRedirect("admin?action=listPV");
    }

    // =============================
    // 📌 BẢN TIN (BÀI BÁO)
    // =============================
    private void listBanTin(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {

        List<BanTinEntity2> list = banTinDAO.getAll();
        req.setAttribute("listBV", list);
        req.getRequestDispatcher("/admin/bantin-list.jsp").forward(req, resp);
    }

    private void addBanTin(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {

        BanTinEntity2 bt = new BanTinEntity2();
        bt.setTieuDe(req.getParameter("tieude"));
        bt.setNoiDung(req.getParameter("noidung"));
        bt.setHinhAnh(req.getParameter("hinhanh"));
        bt.setMaLoai(req.getParameter("maloai"));
        bt.setMaTacGia(Integer.parseInt(req.getParameter("matacgia")));

        banTinDAO.add(bt);

        resp.sendRedirect("admin?action=listBV");
    }

    private void updateBanTin(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {

        BanTinEntity2 bt = new BanTinEntity2();
        bt.setMaBanTin(Integer.parseInt(req.getParameter("mabantin")));
        bt.setTieuDe(req.getParameter("tieude"));
        bt.setNoiDung(req.getParameter("noidung"));
        bt.setHinhAnh(req.getParameter("hinhanh"));
        bt.setMaLoai(req.getParameter("maloai"));

        banTinDAO.update(bt);

        resp.sendRedirect("admin?action=listBV");
    }

    private void deleteBanTin(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, IOException {

        int id = Integer.parseInt(req.getParameter("mabantin"));
        banTinDAO.delete(id);

        resp.sendRedirect("admin?action=listBV");
    }
}
