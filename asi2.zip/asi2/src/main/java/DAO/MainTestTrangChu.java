package DAO;

import ENTITY.TrangChuEntity;
import ENTITY.BanTinEntity;
import ENTITY.LoaiTinEntity;
import ConnectionDatabase.JDBCUtils;

import java.sql.Connection;
import java.util.List;

public class MainTestTrangChu {

    public static void main(String[] args) {
        try {
            // 1. Test kết nối
            System.out.println(">>> Đang kiểm tra kết nối Database...");
            Connection conn = JDBCUtils.getConnection();
            if (conn != null) {
                System.out.println("✅ Kết nối DB thành công!");
            } else {
                System.out.println("❌ Kết nối DB thất bại!");
                return;
            }

            // 2. Tạo DAO trang chủ
            TrangChuDAO dao = new TrangChuDAO();
            TrangChuEntity trangChu = new TrangChuEntity();

            // ============================
            // TEST 1 → LẤY LOẠI TIN
            // ============================
            System.out.println("\n>>> Đang lấy danh sách LOẠI TIN...");
            List<LoaiTinEntity> loaiTinList = dao.getMenuLoaiTin();

            if (loaiTinList == null || loaiTinList.isEmpty()) {
                System.out.println("❌ KHÔNG LẤY ĐƯỢC LOẠI TIN!!!");
            } else {
                System.out.println("✅ ĐÃ LẤY " + loaiTinList.size() + " LOẠI TIN:");
                for (LoaiTinEntity lt : loaiTinList) {
                    System.out.println(" - " + lt.getMaLoai() + " | " + lt.getTenLoai());
                }
            }

            // Gắn vào entity
            trangChu.setMenuLoaiTin(loaiTinList);

            // ============================
            // TEST 2 → LẤY TIN TRANG CHỦ
            // ============================
            System.out.println("\n>>> Đang lấy TIN TRANG CHỦ...");
            List<BanTinEntity> tinTrangChu = dao.getTinTrangChu();
            for (BanTinEntity bt : tinTrangChu) {
                System.out.println(" - " + bt.getTieuDe());
            }
            trangChu.setTinTrangChu(tinTrangChu);

            // ============================
            // TEST 3 → LẤY TIN HOT
            // ============================
            System.out.println("\n>>> Đang lấy TIN HOT...");
            for (BanTinEntity bt : dao.getTinHot()) {
                System.out.println(" - " + bt.getTieuDe() + " | View: " + bt.getLuotXem());
            }
            trangChu.setTinHot(dao.getTinHot());

            // ============================
            // TEST 4 → LẤY TIN MỚI
            // ============================
            System.out.println("\n>>> Đang lấy TIN MỚI...");
            for (BanTinEntity bt : dao.getTinMoi()) {
                System.out.println(" + " + bt.getTieuDe());
            }
            trangChu.setTinMoi(dao.getTinMoi());

            // ============================
            // TEST 5 → LẤY TIN ĐÃ XEM
            // ============================
            System.out.println("\n>>> Đang lấy TIN ĐÃ XEM...");
            List<BanTinEntity> daXem = dao.getTinDaXem("SESSION_TEST_123");
            for (BanTinEntity bt : daXem) {
                System.out.println(" - " + bt.getTieuDe());
            }
            trangChu.setTinDaXem(daXem);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Lỗi trong quá trình test!");
        }
    }
}
