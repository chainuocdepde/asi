package DAO;

import ConnectionDatabase.JDBCUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class login {

    public boolean checkLogin(String maNguoiDung, String matKhau) {
        String sql = """
            SELECT 1 
            FROM NguoiDung
            WHERE MaNguoiDung = ? 
              AND MatKhau = ?
        """;

        try (
            Connection conn = JDBCUtils.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)
        ) {
            ps.setString(1, maNguoiDung);  // ĐÚNG: VARCHAR → setString
            ps.setString(2, matKhau);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();   // Có dòng → đăng nhập đúng
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
