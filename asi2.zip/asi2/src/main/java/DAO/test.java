package DAO;

import ENTITY.DangKyEntity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class test {

    public static void main(String[] args) {

        DangKyDAO dao = new DangKyDAO();

        try {
            // --- 1. Thêm nhân viên mới ---
            DangKyEntity nv1 = new DangKyEntity();
            nv1.setMaNguoiDung("NV001");
            nv1.setMatKhau("123456");
            nv1.setHoTen("Nguyen Van A");
            nv1.setEmail("nva@example.com");
            nv1.setDienThoai("0123456789");
            nv1.setGioiTinh(true);
            nv1.setVaiTro(true);
            nv1.setNgaySinh(new SimpleDateFormat("yyyy-MM-dd").parse("2000-01-01"));

            boolean added = dao.dangKyTaiKhoan(nv1);
            System.out.println("Thêm nhân viên: " + (added ? "Thành công" : "Thất bại"));

            // --- 2. Sửa nhân viên ---
            nv1.setHoTen("Nguyen Van A Updated");
            nv1.setEmail("nva_update@example.com");
            boolean updated = dao.capNhatTaiKhoan(nv1);
            System.out.println("Cập nhật nhân viên: " + (updated ? "Thành công" : "Thất bại"));

            // --- 3. Lấy danh sách nhân viên ---
            List<DangKyEntity> list = dao.findAll();
            System.out.println("Danh sách nhân viên:");
            for (DangKyEntity nv : list) {
                System.out.println(nv.getMaNguoiDung() + " | " + nv.getHoTen() + " | " + nv.getEmail());
            }

            // --- 4. Xóa nhân viên ---
            boolean deleted = dao.xoaTaiKhoan("NV001");
            System.out.println("Xóa nhân viên: " + (deleted ? "Thành công" : "Thất bại"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
