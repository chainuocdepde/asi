package DAO;

import ConnectionDatabase.JDBCUtils;
import ENTITY.BanTinEntity2;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BanTinDAO2 {

    // Thêm bài báo
    public boolean add(BanTinEntity2 bt) throws SQLException {
        String sql = """
            INSERT INTO BanTin (TieuDe, NoiDung, HinhAnh, NgayDang, LuotXem, MaLoai, MaTacGia)
            VALUES (?, ?, ?, GETDATE(), 0, ?, ?)
        """;

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bt.getTieuDe());
            ps.setString(2, bt.getNoiDung());
            ps.setString(3, bt.getHinhAnh());
            ps.setString(4, bt.getMaLoai());
            ps.setInt(5, bt.getMaTacGia());

            return ps.executeUpdate() > 0;
        }
    }

    // Lấy toàn bộ bài báo
    public List<BanTinEntity2> getAll() throws SQLException {
        List<BanTinEntity2> list = new ArrayList<>();
        String sql = "SELECT * FROM BanTin ORDER BY NgayDang DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapBanTin(rs));
            }
        }
        return list;
    }

    // Lấy bài theo loại
    public List<BanTinEntity2> getByLoai(String maLoai) throws SQLException {
        List<BanTinEntity2> list = new ArrayList<>();
        String sql = "SELECT * FROM BanTin WHERE MaLoai = ? ORDER BY NgayDang DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maLoai);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapBanTin(rs));
        }

        return list;
    }

    // Lấy bài theo phóng viên
    public List<BanTinEntity2> getByTacGia(int maTG) throws SQLException {
        List<BanTinEntity2> list = new ArrayList<>();
        String sql = "SELECT * FROM BanTin WHERE MaTacGia = ? ORDER BY NgayDang DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maTG);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapBanTin(rs));
        }

        return list;
    }

    // Update bài báo
    public boolean update(BanTinEntity2 bt) throws SQLException {
        String sql = """
            UPDATE BanTin SET TieuDe=?, NoiDung=?, HinhAnh=?, MaLoai=? 
            WHERE MaBanTin=?
        """;

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bt.getTieuDe());
            ps.setString(2, bt.getNoiDung());
            ps.setString(3, bt.getHinhAnh());
            ps.setString(4, bt.getMaLoai());
            ps.setInt(5, bt.getMaBanTin());

            return ps.executeUpdate() > 0;
        }
    }

    // Xóa bài báo
    public boolean delete(int id) throws SQLException {
        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM BanTin WHERE MaBanTin=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private BanTinEntity2 mapBanTin(ResultSet rs) throws SQLException {
        BanTinEntity2 bt = new BanTinEntity2();
        bt.setMaBanTin(rs.getInt("MaBanTin"));
        bt.setTieuDe(rs.getString("TieuDe"));
        bt.setNoiDung(rs.getString("NoiDung"));
        bt.setHinhAnh(rs.getString("HinhAnh"));
        bt.setNgayDang(rs.getTimestamp("NgayDang"));
        bt.setLuotXem(rs.getInt("LuotXem"));
        bt.setMaLoai(rs.getString("MaLoai"));
        bt.setMaTacGia(rs.getInt("MaTacGia"));
        return bt;
    }
}
