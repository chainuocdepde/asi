package DAO;

import ConnectionDatabase.JDBCUtils;
import ENTITY.PhongVienEntity;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminDAO {

    // Đăng ký tài khoản phóng viên
    public boolean dangKy(PhongVienEntity pv) throws SQLException {
        String sql = """
            INSERT INTO PhongVien (TenPhongVien, Email, Sdt, MatKhau, VaiTro)
            VALUES (?, ?, ?, ?, ?)
        """;

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, pv.getTenPhongVien());
            ps.setString(2, pv.getEmail());
            ps.setString(3, pv.getSdt());
            ps.setString(4, pv.getMatKhau());
            ps.setString(5, pv.getVaiTro());

            return ps.executeUpdate() > 0;
        }
    }

    // Đăng nhập
    public PhongVienEntity login(String email, String matKhau) throws SQLException {
        String sql = "SELECT * FROM PhongVien WHERE Email = ? AND MatKhau = ?";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, matKhau);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapPhongVien(rs);
            }
        }
        return null;
    }

    // Lấy tất cả phóng viên
    public List<PhongVienEntity> getAll() throws SQLException {
        List<PhongVienEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM PhongVien ORDER BY MaPhongVien DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapPhongVien(rs));
            }
        }
        return list;
    }

    // Sửa thông tin phóng viên
    public boolean update(PhongVienEntity pv) throws SQLException {
        String sql = """
            UPDATE PhongVien 
            SET TenPhongVien=?, Email=?, Sdt=?, MatKhau=?, VaiTro=?
            WHERE MaPhongVien=?
        """;

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, pv.getTenPhongVien());
            ps.setString(2, pv.getEmail());
            ps.setString(3, pv.getSdt());
            ps.setString(4, pv.getMatKhau());
            ps.setString(5, pv.getVaiTro());
            ps.setInt(6, pv.getMaPhongVien());

            return ps.executeUpdate() > 0;
        }
    }

    // Xóa phóng viên
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM PhongVien WHERE MaPhongVien = ?";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private PhongVienEntity mapPhongVien(ResultSet rs) throws SQLException {
        PhongVienEntity pv = new PhongVienEntity();
        pv.setMaPhongVien(rs.getInt("MaPhongVien"));
        pv.setTenPhongVien(rs.getString("TenPhongVien"));
        pv.setEmail(rs.getString("Email"));
        pv.setSdt(rs.getString("Sdt"));
        pv.setMatKhau(rs.getString("MatKhau"));
        pv.setVaiTro(rs.getString("VaiTro"));
        return pv;
    }
}
