package DAO;

import ConnectionDatabase.JDBCUtils;
import ENTITY.BanTinEntity;
import ENTITY.LoaiTinEntity;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrangChuDAO {

    // =============================
    // Lấy menu loại tin
    // =============================
    public List<LoaiTinEntity> getMenuLoaiTin() throws SQLException {
        List<LoaiTinEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM LoaiTin ORDER BY TenLoai";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                LoaiTinEntity lt = new LoaiTinEntity();
                lt.setMaLoai(rs.getString("MaLoai"));
                lt.setTenLoai(rs.getString("TenLoai"));
                list.add(lt);
            }
        }
        return list;
    }

    // =============================
    // Tin Trang Chủ (1 tin lớn)
    // =============================
    public List<BanTinEntity> getTinTrangChu() throws SQLException {
        List<BanTinEntity> list = new ArrayList<>();
        String sql = "SELECT TOP 1 * FROM BanTin WHERE TrangChu = 1 ORDER BY NgayDang DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapBanTin(rs));
            }
        }
        return list;
    }

    // =============================
    // Tin HOT
    // =============================
    public List<BanTinEntity> getTinHot() throws SQLException {
        List<BanTinEntity> list = new ArrayList<>();
        String sql = "SELECT TOP 5 * FROM BanTin ORDER BY LuotXem DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapBanTin(rs));
            }
        }
        return list;
    }

    // =============================
    // Tin Mới
    // =============================
    public List<BanTinEntity> getTinMoi() throws SQLException {
        List<BanTinEntity> list = new ArrayList<>();
        String sql = "SELECT TOP 5 * FROM BanTin ORDER BY NgayDang DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapBanTin(rs));
            }
        }
        return list;
    }

    // =============================
    // Tin đã xem theo user or session
    // =============================
    public List<BanTinEntity> getTinDaXem(String maNguoiDungOrSession) throws SQLException {
        List<BanTinEntity> list = new ArrayList<>();

        String sql = """
                SELECT TOP 5 BT.* 
                FROM BanTin BT 
                JOIN LichSuXemTin LS ON BT.MaBanTin = LS.MaBanTin
                WHERE LS.MaNguoiDung = ? OR LS.SessionID = ?
                ORDER BY LS.ThoiGianXem DESC
                """;

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maNguoiDungOrSession);
            ps.setString(2, maNguoiDungOrSession);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapBanTin(rs));
                }
            }
        }
        return list;
    }

    // =============================
    // Lấy bản tin theo ID
    // =============================
    public BanTinEntity getTinById(String maBanTin) throws SQLException {
        String sql = "SELECT * FROM BanTin WHERE MaBanTin = ?";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maBanTin);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapBanTin(rs);
                }
            }
        }
        return null;
    }

    // =============================
    // Tăng lượt xem
    // =============================
    public void tangLuotXem(String maBanTin) throws SQLException {
        String sql = "UPDATE BanTin SET LuotXem = LuotXem + 1 WHERE MaBanTin = ?";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maBanTin);
            ps.executeUpdate();
        }
    }

    // =============================
    // Tin khác (không trùng tin hiện tại)
    // =============================
    public List<BanTinEntity> getTinKhac(String maBanTin) throws SQLException {
        List<BanTinEntity> list = new ArrayList<>();

        String sql = "SELECT TOP 6 * FROM BanTin WHERE MaBanTin <> ? ORDER BY NgayDang DESC";

        try (Connection conn = JDBCUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maBanTin);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BanTinEntity t = new BanTinEntity();
                t.setMaBanTin(rs.getString("MaBanTin"));
                t.setTieuDe(rs.getString("TieuDe"));
                t.setHinhAnh(rs.getString("HinhAnh"));
                list.add(t);
            }
        }
        return list;
    }

    // =============================
    // MAP BẢN TIN
    // =============================
    private BanTinEntity mapBanTin(ResultSet rs) throws SQLException {
        BanTinEntity bt = new BanTinEntity();
        bt.setMaBanTin(rs.getString("MaBanTin"));
        bt.setTieuDe(rs.getString("TieuDe"));
        bt.setNoiDung(rs.getString("NoiDung"));
        bt.setHinhAnh(rs.getString("HinhAnh"));
        bt.setNgayDang(rs.getTimestamp("NgayDang"));
        bt.setLuotXem(rs.getInt("LuotXem"));
        bt.setMaLoai(rs.getString("MaLoai"));
        bt.setMaTacGia(rs.getString("MaTacGia"));
        return bt;
    }
 // =============================
 // Lấy tin theo loại
 // =============================
 public List<BanTinEntity> getTinTheoLoai(String maLoai) throws SQLException {
     List<BanTinEntity> list = new ArrayList<>();
     String sql = "SELECT * FROM BanTin WHERE MaLoai = ? ORDER BY NgayDang DESC";

     try (Connection conn = JDBCUtils.getConnection();
          PreparedStatement ps = conn.prepareStatement(sql)) {

         ps.setString(1, maLoai);

         try (ResultSet rs = ps.executeQuery()) {
             while (rs.next()) {
                 list.add(mapBanTin(rs));
             }
         }
     }
     return list;
 }

    
}
