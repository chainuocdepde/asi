package CONTROLLER;

import DAO.LoaiTinDAO;
import ENTITY.LoaiTinEntity;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/loaitin")
public class LoaiTinController extends HttpServlet {

    LoaiTinDAO dao = new LoaiTinDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if ("add".equals(action)) {
            String ma = req.getParameter("ma");
            String ten = req.getParameter("ten");
            dao.insert(new LoaiTinEntity(ma, ten));

        } else if ("edit".equals(action)) {
            String ma = req.getParameter("ma");
            String ten = req.getParameter("ten");
            dao.update(new LoaiTinEntity(ma, ten));

        } else if ("delete".equals(action)) {
            String ma = req.getParameter("ma");
            dao.delete(ma);
        }

        resp.sendRedirect("quanlyloaitin.jsp");
    }
}
