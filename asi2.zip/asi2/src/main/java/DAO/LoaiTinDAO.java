package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import ConnectionDatabase.JDBCUtils;
import ENTITY.LoaiTinEntity;

public class LoaiTinDAO {

    public List<LoaiTinEntity> getAll() {
        List<LoaiTinEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM LoaiTin";

        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new LoaiTinEntity(
                        rs.getString("MaLoai"),
                        rs.getString("TenLoai")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int insert(LoaiTinEntity lt) {
        String sql = "INSERT INTO LoaiTin (MaLoai, TenLoai) VALUES (?, ?)";

        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, lt.getMaLoai());
            ps.setString(2, lt.getTenLoai());

            return ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int update(LoaiTinEntity lt) {
        String sql = "UPDATE LoaiTin SET TenLoai=? WHERE MaLoai=?";

        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, lt.getTenLoai());
            ps.setString(2, lt.getMaLoai());

            return ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int delete(String ma) {
        String sql = "DELETE FROM LoaiTin WHERE MaLoai=?";

        try (Connection con = JDBCUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ma);
            return ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}

