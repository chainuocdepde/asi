package CONTROLLER;

import DAO.TrangChuDAO;
import ENTITY.LoaiTinEntity;
import ENTITY.TrangChuEntity;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = {"/TrangChu", "/trang-chu"})
public class TrangChuController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        TrangChuDAO dao = new TrangChuDAO();

        try {
            // ===== LẤY MENU LOẠI TIN =====
            List<LoaiTinEntity> menuLoaiTin = dao.getMenuLoaiTin();
            request.getSession().setAttribute("menuLoaiTin", menuLoaiTin);

            // ===== LẤY mã loại người dùng chọn =====
            String maLoai = request.getParameter("maLoai");

            TrangChuEntity trangChu = new TrangChuEntity();
            trangChu.setMenuLoaiTin(menuLoaiTin);

            // ===== BÀI TRANG CHỦ =====
            if (maLoai != null && !maLoai.isBlank()) {
                // Lọc theo loại
                trangChu.setTinTrangChu(dao.getTinTheoLoai(maLoai));
                request.setAttribute("maLoai", maLoai);
            } else {
                // Trang chủ mặc định
                trangChu.setTinTrangChu(dao.getTinTrangChu());
            }

            // ===== LUÔN LOAD CÁC MỤC KHÁC =====
            trangChu.setTinHot(dao.getTinHot());
            trangChu.setTinMoi(dao.getTinMoi());

            // ===== Tin đã xem (dùng session ID) =====
            String sessionId = request.getSession().getId();
            trangChu.setTinDaXem(dao.getTinDaXem(sessionId));

            // ===== GỬI DỮ LIỆU SANG JSP =====
            request.setAttribute("trangChu", trangChu);
            request.getRequestDispatcher("/trangchudemo.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Lỗi TrangChuController: " + e.getMessage());
        }
    }
}
