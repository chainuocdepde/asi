package ENTITY;

import java.sql.Timestamp;

public class BanTinEntity2 {

    private int MaBanTin;           // PK tự tăng
    private String TieuDe;
    private String NoiDung;
    private String HinhAnh;
    private Timestamp NgayDang;
    private int LuotXem;
    private String MaLoai;          // FK: loại tin
    private int MaTacGia;           // FK: phóng viên đăng bài

    public BanTinEntity2() {
    }

    public int getMaBanTin() {
        return MaBanTin;
    }

    public void setMaBanTin(int maBanTin) {
        MaBanTin = maBanTin;
    }

    public String getTieuDe() {
        return TieuDe;
    }

    public void setTieuDe(String tieuDe) {
        TieuDe = tieuDe;
    }

    public String getNoiDung() {
        return NoiDung;
    }

    public void setNoiDung(String noiDung) {
        NoiDung = noiDung;
    }

    public String getHinhAnh() {
        return HinhAnh;
    }

    public void setHinhAnh(String hinhAnh) {
        HinhAnh = hinhAnh;
    }

    public Timestamp getNgayDang() {
        return NgayDang;
    }

    public void setNgayDang(Timestamp ngayDang) {
        NgayDang = ngayDang;
    }

    public int getLuotXem() {
        return LuotXem;
    }

    public void setLuotXem(int luotXem) {
        LuotXem = luotXem;
    }

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String maLoai) {
        MaLoai = maLoai;
    }

    public int getMaTacGia() {
        return MaTacGia;
    }

    public void setMaTacGia(int maTacGia) {
        MaTacGia = maTacGia;
    }
}
